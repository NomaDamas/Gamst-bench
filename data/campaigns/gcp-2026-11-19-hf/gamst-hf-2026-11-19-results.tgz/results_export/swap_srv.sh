#!/usr/bin/env bash
# runs on VM; kills old jobs by pid list so it never matches itself
for p in $(pgrep -f 'gcp-2026-11-19/(fetch_videos|setup_vm)'); do [ "$p" != "$$" ] && kill "$p" 2>/dev/null; done
for p in $(pgrep -f 'gcloud storage|uv pip|hf download'); do kill "$p" 2>/dev/null; done
sleep 2
if [ ! -L /srv ]; then
  rsync -a --delete --exclude data/tmp /srv/ /mnt/ssd/
  rm -rf /mnt/ssd/data/tmp
  sudo mv /srv /srv.old && sudo ln -s /mnt/ssd /srv
  grep -q google-hfdata /etc/fstab || echo "/dev/disk/by-id/google-hfdata /mnt/ssd ext4 discard,defaults,nofail 0 2" | sudo tee -a /etc/fstab >/dev/null
fi
cp /tmp/*.py /tmp/*.sh /srv/bench/scripts/gcp-2026-11-19/ 2>/dev/null
for d in /srv/data/streamarena/videos/*/; do v=$(basename "$d"); [ -s "$d/$v.mp4" ] || rm -rf -- "$d"; done
cd /srv
setsid nohup bash /srv/bench/scripts/gcp-2026-11-19/setup_vm.sh > /srv/setup.log 2>&1 < /dev/null &
setsid nohup bash /srv/bench/scripts/gcp-2026-11-19/fetch_videos.sh > /srv/fetch.log 2>&1 < /dev/null &
(sudo rm -rf /srv.old &)
ls -la / | grep srv; df -h /srv/ | tail -1; echo relaunched
